package com.marwadi.sensordemo;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraManager;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    //sensor objects
    private SensorManager sensorManager;
    private Sensor accelerometer;

    //flash control variables
    private CameraManager cameraManager;
    private String cameraId;
    private boolean isFlashOn = false;
    //UI
    private TextView txtstatus;

    //Shake detection config
    private static final float ALPHA = 0.8f; //filter constant
    private static final float SHAKE_THRESHOLD = 12f;
    private static final long SHAKE_DELAY = 1000; // 1 sec gap

    // For filtering values
    private final float[] gravity = new float[3];
    private final float[] linear = new float[3];
    private long lastShakeTime = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        initViews();
        setupSensor();
        setupFlash();
    }

    private void initViews() {
        txtstatus = findViewById(R.id.txtstatus);
    }

    @Override
    protected void onResume() {
        if (sensorManager != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
        super.onResume();
    }

    @Override
    protected void onPause() {
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
        super.onPause();
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        // Step 1: remove gravity effect
        gravity[0] = ALPHA * gravity[0] + (1 - ALPHA) * event.values[0];
        gravity[1] = ALPHA * gravity[1] + (1 - ALPHA) * event.values[1];
        gravity[2] = ALPHA * gravity[2] + (1 - ALPHA) * event.values[2];

        linear[0] = event.values[0] - gravity[0];
        linear[1] = event.values[1] - gravity[1];
        linear[2] = event.values[2] - gravity[2];

        // Step 2: calculate movement
        float magnitude = (float) Math.sqrt(linear[0] * linear[0] + linear[1] * linear[1] + linear[2] * linear[2]);

        // Step 3: detect shake with delay
        long now = System.currentTimeMillis();
        if (magnitude > SHAKE_THRESHOLD && (now - lastShakeTime) > SHAKE_DELAY) {
            lastShakeTime = now;
            toggleFlash();
        }
    }

    /** set up the acceslator sensor*/

    private void setupSensor()
    {
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager != null){
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        }
    }

    private void setupFlash()
    {
        cameraManager = (CameraManager) getSystemService(CAMERA_SERVICE);
        try {
            if (cameraManager != null) {
                cameraId = cameraManager.getCameraIdList()[0];
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void toggleFlash(){
        try {
            if (cameraManager == null || cameraId == null) return;

            isFlashOn = !isFlashOn;
            cameraManager .setTorchMode(cameraId, isFlashOn);
            if (txtstatus != null) {
                txtstatus.setText(isFlashOn ? "Flash: ON" : "Flash: OFF");
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
