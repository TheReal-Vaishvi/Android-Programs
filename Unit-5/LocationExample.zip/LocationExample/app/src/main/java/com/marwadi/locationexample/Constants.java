package com.marwadi.locationexample;

import android.Manifest;

/**
 * * Constants for the app
 */
public class Constants {
    //Constants
    public static final String LOCATION_PERMISSION = Manifest.permission.ACCESS_FINE_LOCATION;
    // Request codes
    public static final int LOCATION_PERMISSION_REQUEST_CODE = 100;

}