package com.marwadi.locationexample;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        if (!isLocationPermissionGranted()) {
            requestLocationPermission();
        }
        startLocationFetch();
        useOfGeoCoder();
    }

    private void useOfGeoCoder() {
        // This method is called in onCreate. 
        // You can use it for manual geocoding or testing.
        Log.d("MainActivity", "useOfGeoCoder called");
    }

    private void startLocationFetch() {
        Log.i("MainActivity", "Start - startLocationFetch()");

        // Get the FusedLocationProviderClient
        FusedLocationProviderClient fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null) {
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();

                String locationString = "Latitude: " + latitude + ", Longitude: " + longitude;
                Toast.makeText(this, locationString, Toast.LENGTH_SHORT).show();

                Log.d("Location", latitude + ", " + longitude);
                getGeoCoding(latitude, longitude);
            }
        }).addOnFailureListener(e -> {
            Log.e("LocationError", "Failed to get location", e);
        });

        Log.i("MainActivity", "End - startLocationFetch()");
    }

    private boolean isLocationPermissionGranted() {
        return ContextCompat.checkSelfPermission(this, Constants.LOCATION_PERMISSION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Constants.LOCATION_PERMISSION}, Constants.LOCATION_PERMISSION_REQUEST_CODE);
    }

    private void getGeoCoding(double latitude, double longitude) {
        String address = GeoCoderUtil.getAddressFromLocation(this, latitude, longitude);
        Log.d("GeoCoding", "Address: " + address);
        Toast.makeText(this, "Address: " + address, Toast.LENGTH_LONG).show();
    }
}
