package com.marwadi.locationexample;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.util.Log;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class GeoCoderUtil {

    public static String getAddressFromLocation(Context context, double latitude, double longitude) {
        try {
            Geocoder geocoder = new Geocoder(context, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address address = addresses.get(0);
                String fullAddress = address.getAddressLine(0);
                Log.d("Location", fullAddress);
                return fullAddress;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null; // Added default return statement to fix error
    }
}
